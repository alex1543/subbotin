
RSS weather post scripts
(c) Stas Degteff 2:5080/102

Retrieve weather data (ekaterinburg) and post it into specified echo.

Place  use cron for periodic run weather.post

